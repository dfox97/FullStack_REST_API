Problems with my program:

Average age not working in sql.
Interface website doesnt fully function only can call url link and get requests.

Will need to run tests through postman or RESTED to test other methods.

Other small errors may be present.



Postman tests WORK instructions displayed in interface.

GET Teams works

GET Players by team works
(if team id doesnt exist it will say )

GET Players by pid works
(if player id doesnt excist it will print out a message)


POST 
Adding player to team works 
tid/{tidnum}
determines where the player gets added to the team

if primary key excist it will say uncaught expression


DELETE
Delete player by url link
if tid and pid set in url itll delete that player.
If u try and delete a non existing member it just says player removed FIX??


PUT 
Player update works